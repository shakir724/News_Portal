

<link rel="stylesheet" href="stylen.css">

<nav class="navbar navbar1">
        <div class="navbar-left">
            <button class="nav-btn" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><i class="fas fa-bars"></i></button>


            <a href="#">
                <h3>LOGO</h3>
            </a>
        </div>

        <?php 
   include 'db.php';
   session_start();

   $result = mysqli_query($con, "SELECT * FROM register WHERE register_id = '".$_SESSION['register_id']."' ");
    while ($row = mysqli_fetch_array($result)) {
            $paid = $row['paid'];
    }
    if ($paid == "1")
    {
       // echo "paid user";
 //   } else {
   //     header('location:pay1.php');
     //   exit();
    
?>
        <div class="navbar-right">
            <button><i class="fas fa-home fa-lg nav-i1"></i></button>
            <button onclick="location.href='notification.php'"><i class="far fa-bell fa-lg nav-i1"></i></button>

        </div>
        <?php
    } else {
        ?>
        <div class="navbar-right">
                <button><i class="fas fa-home fa-lg nav-i1"></i></button>
                <button onclick="location.href='notification.php'"><i class="far fa-bell fa-lg nav-i1"></i><sup class="bell-i">1</sup></button>

            </div>

            <?php
        }
        ?>


    </nav>

    <div class="collapse navbar-collapse nav-dropdown" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="nav-link" href="home.php">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="profile.php">Profile </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="postnews.php">Post News</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="events.php">Events</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="wallet.php">Wallet</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="kyc.php">Kyc</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="mynews.php">My News</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="chatpanel.php">Chat Panel</a>
            </li>

        </ul>
    </div>