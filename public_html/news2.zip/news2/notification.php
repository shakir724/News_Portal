<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css" integrity="sha384-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d3Gp2irVfcrp" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="style3.css">
    <!--    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>-->

    <title></title>

    <style>
        * {
            margin: 0;
            padding: 0;
        }

        body {
            margin-top: 3.6rem;
            margin-bottom: 2rem;
        }

        /*Navbar*/
        header {
            width: 100%;
            height: auto;
            /* background: red; */
            position: fixed;
            top: 0;
            left: 0;
            z-index: 100;
        }

        .navbar1 {
            background: linear-gradient(#fbd253, #fc9813);
        }

        button.nav-btn {
            border: none;
            background-color: transparent;
            color: #fff;
            font-size: 25px;
            margin-top: -5px;
            margin-left: -4px;
            outline: none;
        }

        .navbar1 .navbar-left {
            display: flex;
        }

        .navbar1 .navbar-left a {
            text-decoration: none;
        }

        .navbar1 .navbar-left h3 {
            margin-left: 16px;
            letter-spacing: 8px;
            color: #fff;
            margin-bottom: 0;
            margin-top: -3px;
        }

        .navbar1 .navbar-right button {
            background: none;
            border: none;
            outline: none;
        }

        .navbar1 .navbar-right .nav-i1 {
            color: #fff;
            margin-right: 5px;
            font-size: 25px;
        }

        .navbar1 .navbar-right .bell-i {
            background: red;
            color: #fff;
            padding: 0 4px;
            border-radius: 8px;
            right: .8rem;
            top: -.6rem;
        }

        /*---------*/
        /*Notification*/
        #noti a {
            text-decoration: none;
            background-color: #fff;
        }

        #noti .card2 {
            padding: 6px 0;
        }

        #noti .card2:hover {
            background: lightgray;
        }

        #noti .noti-img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
        }

        #noti .noti-col {
            padding-left: 0;
            padding-top: 5px;
        }

        #noti .noti-p1 {
            margin-bottom: 0;
            color: #333;
        }

        #noti .noti-p2 {
            margin-bottom: 0;
            font-size: small;
            color: slategray;
        }

        /*--------*/

        footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            /*    left: 0;*/
            background: #333;
            text-align: center;
            padding: 3px;
        }

        footer button {
            border: none;
            outline: none !important;
            background: none;
        }

        footer button i {
            color: #fff;
            font-size: 18px;
        }

        .footer-plus-btn {
            width: 25px;
            height: 25px;
            background: orange;
            border-radius: 50%;
            /*    padding: 5px;*/
            padding-top: 3px;
            font-size: 18px;
        }

        @media screen and (max-width: 400px) {
            #noti .noti-img {
                width: 60px;
                height: 60px;
            }

            #noti .noti-p1 {
                font-size: 13px;
            }
        }

        @media screen and (min-width: 780px) {
            body {
                padding: 0 32%;
            }

            header {
                padding-left: 32%;
                padding-right: 32%;
            }

            footer {
                left: 32%;
                width: 36%;
            }
        }

    </style>
</head>

<body class="noti-body">

    <header>
        <?php 
        include 'header.php';
        ?>
       <!-- <nav class="navbar navbar1">
            <div class="navbar-left">
                <button class="nav-btn"><i class="fas fa-bars"></i></button>
                <a href="#">
                    <h3>LOGO</h3>
                </a>
            </div>
            <div class="navbar-right">
                <button><i class="fas fa-home fa-lg nav-i1"></i></button>
                <button><i class="far fa-bell fa-lg nav-i1"></i><sup class="bell-i">1</sup></button>

            </div>
        </nav>  -->
    </header>

    <section id="noti">
        <div class="container-fluid">
            <h4>Notifications</h4>
            <?php
            $result = mysqli_query($con, "SELECT * FROM register WHERE register_id = '".$_SESSION['register_id']."' ");
            while ($row = mysqli_fetch_array($result)) {
                $paid = $row['paid'];
            }
            if ($paid == "1")
            {
                   // echo "string";
            } else {
                ?> 

                <a href="pay1.php">
                    <div class="row card2">
                        <div class="col-3">
                            <img src="perfil.jpg" class="noti-img">
                        </div>
                        <div class="col noti-col">
                            <p class="noti-p1">Only Paid User can post a News, Like and Comment on News <span><b></b></span></p>

                            <p class="noti-p2">3 hours ago</p>
                        </div>
                    </div>
                </a> 
             <?php
            } ?>
                
            <!--    <a href="#">
                    <div class="row card2">
                        <div class="col-3">
                            <img src="perfil.jpg" class="noti-img">
                        </div>
                        <div class="col noti-col">
                            <p class="noti-p1">Lorem ipsum dolor sit amet, consectetur adipiscing elit: <span><b>Demo text</b></span></p>

                            <p class="noti-p2">3 hours ago</p>
                        </div>
                    </div>
                </a>

                <a href="#">
                    <div class="row card2">
                        <div class="col-3">
                            <img src="perfil.jpg" class="noti-img">
                        </div>
                        <div class="col noti-col">
                            <p class="noti-p1">Lorem ipsum dolor sit amet, consectetur adipiscing elit: <span><b>Demo text</b></span></p>

                            <p class="noti-p2">3 hours ago</p>
                        </div>
                    </div>
                </a>

                <a href="#">
                    <div class="row card2">
                        <div class="col-3">
                            <img src="perfil.jpg" class="noti-img">
                        </div>
                        <div class="col noti-col">
                            <p class="noti-p1">Lorem ipsum dolor sit amet, consectetur adipiscing elit: <span><b>Demo text</b></span></p>

                            <p class="noti-p2">3 hours ago</p>
                        </div>
                    </div>
                </a>

                <a href="#">
                    <div class="row card2">
                        <div class="col-3">
                            <img src="perfil.jpg" class="noti-img">
                        </div>
                        <div class="col noti-col">
                            <p class="noti-p1">Lorem ipsum dolor sit amet, consectetur adipiscing elit: <span><b>Demo text</b></span></p>

                            <p class="noti-p2">3 hours ago</p>
                        </div>
                    </div>
                </a>  -->


            </div>
        </section>


        <div class="footer">
            <footer>
                <div class="row">
                    <div class="col">
                        <button><i class="fas fa-search"></i></button>
                    </div>
                    <div class="col">
                        <button><i class="fab fa-gratipay"></i></button>
                    </div>
                    <div class="col">
                        <button><i class="fas fa-plus footer-plus-btn"></i></button>
                    </div>
                    <div class="col">
                        <button><i class="far fa-newspaper"></i></button>
                    </div>
                    <div class="col">
                        <button><i class="fas fa-user"></i></button>
                    </div>
                </div>
            </footer>
        </div>


        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    </body>

    </html>
