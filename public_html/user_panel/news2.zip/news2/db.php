<?php
$servername = "localhost";
$database = "news1";
$username = "root";
$password = "";

// Create connection

$con = mysqli_connect($servername, $username, $password, $database);

// Check connection

if ($con->connect_error) {
die("Connection failed: " . $con->connect_error);
}

//echo “Connected successfully”;

//mysqli_close($con);

?>